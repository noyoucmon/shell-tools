﻿Shell Tools
===========

Shell scripts to make life easier. 

## git-export.sh

Exports the current repo into a ZIP file. `-b` defaults to `master`.

```bash
sh GIT-EXPORT.sh [-b BRANCH]
```